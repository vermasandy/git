function calculateBMI(){
	var weight = $("#kg").val();
	var height = parseInt($("#cm").val())/100;
    if (weight == "" || height == "") {
        $("#field_error").html("<span class='text-danger'>Please fill both Fields</span>");
        return false;
    }
    if (weight != "" || height != "") {
        $("#field_error").html("");        
    }
	var bmi = weight / (height * height);
    var color = "success";
	var type = "Normal";	
	if (bmi < 15){
		type= "Very severely underweight";
        color = "primary";
	}else if(bmi <=16){
		type= "Severely underweight";
        color="info";
	}else if(bmi <=18.4){
		type= "Underweight";
        color="info";
	}else if(bmi <=24.9){
		type= "Normal";
        color="success";
	}else if(bmi <=29.9){
		type= "Overweight";
        color="warning";
	}else if(bmi <=34.9){
		type= "Obese Class I (Moderately obese)";
        color="warning";
	}else if(bmi <=39.9){
		type= "Obese Class II (Severely obese)";
        color="danger";
	}else{
		type= "Obese Class III (Very severely obese)";
        color="danger";
	}    
	$("#bmiresults").html('<div class="alert alert-dismissible alert-'+color+'"><button type="button" class="close" data-dismiss="alert">×</button><center><h1><strong>'+bmi.toFixed(1)+'</strong></h1>'+type+'</center></div>');
}

function checkbp(){
    $("#bpresult").html("");
    var age = $("#age").val();
    var sbp = $("#sbp").val();
    var dbp = $("#dbp").val();
    if (age == "" || sbp == "" || dbp == "") {
        ("#bp_error").html("<span class='text-danger'>Please fill All fields</span>");
        return false;
    }
    if (age != "" || sbp != "" || dbp != "") {
        $("#bp_error").html("");
        var frac = +sbp + 2* +dbp;
        var map = Math.round((frac)/3);
        var bp = "Normal";
if(age>=1 && age<=5){
    if(map>=63 && map<75){
       bp="Low";
    }
    if(map>=75 && map<89){
        bp="Normal";
    }
    if(map>=89){
        bp="High";
    }
}
if(age>5 && age<=13){
    if(map>=70 && map<82){
        bp="Low";
    }
    if(map>82 && map<92){
        bp="Normal";
    }
    if(map>=92){
        bp="High";
    }
}
if(age>13 && age<=19){
    if(map>=84 && map<90){
        bp="Low";
    }
    if(map>90 && map<94){
        bp="Normal";
    }
    if(map>=94){
        bp="High";
    }
}
if(age>19 && age<=24){
    if(map>=86 && map<93){
        bp="Low";
    }
    if(map>93 && map<99){
        bp="Normal";
    }
    if(map>=99){
        bp="High";
    }
}
if(age>24 && age<=29){
    if(map>=87 && map<94){
        bp="Low";
    }
    if(map>94 && map<100){
        bp="Normal";
    }
    if(map>=100){
        bp="High";
    }
}
if(age>29 && age<=34){
    if(map>=88 && map<95){
        bp="Low";
    }
    if(map>95 && map<101){
        bp="Normal";
    }
    if(map>=101){
        bp="High";
    }
}
if(age>34 && age<=39){
    if(map>=89 && map<96){
        bp="Low";
    }
    if(map>96 && map<102){
        bp="Normal";
    }
    if(map>=102){
        bp="High";
    }
}
if(age>39 && age<=44){
    if(map>=90 && map<97){
        bp="Low";
    }
    if(map>97 && map<104){
        bp="Normal";
    }
    if(map>=104){
        bp="High";
    }
}
if(age>44 && age<=49){
    if(map>=92 && map<98){
        bp="Low";
    }
    if(map>98 && map<105){
        bp="Normal";
    }
    if(map>=105){
        bp="High";
    }
}
if(age>49 && age<=54){
    if(map>=93 && map<99){
        bp="Low";
    }
    if(map>99 && map<107){
        bp="Normal";
    }
    if(map>=107){
        bp="High";
    }
}
if(age>54 && age<=59){
    if(map>=94 && map<101){
        bp="Low";
    }
    if(map>101 && map<108){
        bp="Normal";
    }
    if(map>=108){
        bp="High";
    }
}
if(age>59 && age<=64){
    if(map>=96 && map<103){
        bp="Low";
    }
    if(map>103 && map<110){
        bp="Normal";
    }
    if(map>=110){
        bp="High";
    }
}
if(bp != "Low" && bp != "Normal" && bp != "High" && bp == ""){
	bp = "Error";
	
}
 switch (bp) {
    case 'Normal':
        $("#bpresult").html('<div class="panel panel-success"><div class="panel-heading"><h3 class="panel-title"><i class="fa fa-smile-o"></i> Normal Blood Pressure</h3></div><div class="panel-body"><h4 class="text-primary">Nothing to Worry Your Blood pressure is Under Normal Range</h4>Mean Arterial Pressure(MAP): <span class="label label-primary">'+map+'</span> mmHg</div></div>');
        break;
    case 'Low':
        $("#bpresult").html('<div class="panel panel-primary"><div class="panel-heading"><h3 class="panel-title"><i class="fa fa-meh-o"></i> Low Blood Pressure</h3></div><div class="panel-body"><h4 class="text-primary">Your Blood pressure is Below Normal Range</h4>Mean Arterial Pressure(MAP): <span class="label label-primary">'+map+'</span> mmHg</div></div>');
        break;
    case 'High':
        $("#bpresult").html('<div class="panel panel-danger"><div class="panel-heading"><h3 class="panel-title"><i class="fa fa-frown-o"></i> High Blood Pressure</h3></div><div class="panel-body"><h4 class="text-primary">Your Blood pressure is Above Normal Range</h4>Mean Arterial Pressure(MAP): <span class="label label-primary">'+map+'</span> mmHg</div></div>');
        break;
    case 'Error':
        $("#bpresult").html('<div class="panel panel-danger"><div class="panel-heading"><h3 class="panel-title"><i class="fa fa-ban"></i> Please Provide Accurate Data</h3></div><div class="panel-body"><h4 class="text-primary">SBP and DBP should be Accurate According to your Age Range</h4>Mean Arterial Pressure(MAP): <span class="label label-primary">'+map+'</span> mmHg</div></div>');
        break;
 }

    }        
}