function medsAPIcall(query) {
    $('#imed').prop('class', 'fa fa-spinner fa-pulse');
    if (query == "") {
        $("#med_error").html('Please Enter Medicine Name');
        $('#imed').prop('class', 'fa fa-search');
        return false;
    }
    if (query != "") {
        $("#med_error").html("");
    }
    $.ajax({
        url: "http://jagroopsingh.byethost11.com/getMeds.php",
        data: {
            'q': query
        },
        dataType: "jsonp",
        jsonp: "mycallback",
        success: function(response) {
            $('#imed').prop('class', 'fa fa-search');
            $("#results").html("");
            if (response.type == "suggestions") {
                $("#results").append("<h4 class='text-primary'><b>Suggestions found</b></h4>");
                jQuery.each(response.data, function(i, val) {
                    $("#results").append("<a id='" + val + "' onclick='medsAPIcall(this.id);' class='btn btn-link' href='javascript:void(0);'>" + val + "</a>" + "<br>");
                });
            }
            if (response.type == "details") {
                console.log(response);
                var detials = response.data;
                var cons = response.cons;
                $("#results").append("<h4><span class='label label-info'><i class='fa fa-medkit'></i>&nbsp;" + detials.brand + "</span></h4>");
                $("#results").append("<table style='font-size: inherit;' class='table table-striped table-hover '><tr><td>Manufacturer:</td><td>" + detials.manufacturer + "</td></tr><tr><td>Package Price:</td><td>" + detials.package_price + "&nbsp;<i class='fa fa-inr'></i>" + "</td></tr><tr><td>Package Qty:</td><td>" + detials.package_qty + " " + detials.package_type + "</td></tr><tr><td>Unit Price:</td><td>" + detials.unit_price + "&nbsp;<i class='fa fa-inr'></i>" + "</td></tr><tr><td>Unit Qty:</td><td>" + detials.unit_qty + " " + detials.unit_type + "</td></tr></table>");
                $("#results").append('<hr size="3"/><h4><span class="label label-info"><i class="fa fa-flask"></i> Composition</span></h4>');
                jQuery.each(cons, function(i, val) {
                    $("#results").append("<span class='label label-default'>" + val.name + "</span> (" + val.strength + ")");
                });
            }
            if (response.type == "empty") {
                $("#results").append('<h3 class="text-danger"><b>No results found</b></h3>');
            }
        }
    });
}

function rssAPIcall(str) {
    $("#rssresults").html("");
    $.ajax({
        url: "http://jagroopsingh.byethost11.com/rss.php",
        data: {
            'q': str
        },
        dataType: "jsonp",
        jsonp: "mycallback",
        success: function(response) {
            jQuery.each(response.channel.item, function(i, val) {
                $("#rssresults").append('<a href="' + val.link + '" style="text-decoration: none;"><h4 class="text-info"><i class="fa fa-rss"></i>' + val.title + '</h4></a>');
                $("#rssresults").append('<p class="text-muted">' + val.description + '</p>');
                $("#rssresults").append('<hr size="5"/>');
            });
        }
    });
}

function loginReg(action) {
    if (action == "login") {
        var e = $("#loginemail").val();
        var p = $("#loginpassword").val();
        if (e == "" || p == "") {
            $("#login_error").html("<span class='text-danger'>Please fill both fields</span>");
        }
        if (e != "" || p != "") {
            $("#loginbtn").html("<i class='fa fa-spinner fa-pulse fa-2x'></i>");
            $("#login_error").html("");
            $.ajax({
                url: "http://jagroopsingh.byethost11.com/loginReg.php",
                data: {
                    'login': action,
                    'email': e,
                    'password': p
                },
                dataType: "jsonp",
                jsonp: "mycallback",
                success: function(response) {
                    if (response.login == "success") {
                        var uid = localStorage.setItem('uid', response.user_id);
                        var uname = localStorage.setItem('user_name', response.user_name);
                        window.location = "index.html";
                    }
                    if (response.login == "error") {
                        $("#loginbtn").html('<i class="fa fa-sign-in"></i> Login');
                        $("#login_error").html("<span class='text-danger'>Wrong Email Or Password</span>");
                        return false;
                    }
                }
            });
        }
    }
    if (action == "reg") {        
        var name = $("#regName").val();
        var email = $("#regEmail").val();
        var password = $("#regPassword").val();
        if (name == "" || email == "" || password == "") {
            $("#reg_error").html("<span class='text-danger'>Please fill All fields</span>");
            return false;
        }
        if (name != "" || email != "" || password != "") {
            $("#regbtn").html("<i class='fa fa-spinner fa-pulse'></i> please wait..");
            $("#reg_error").html("");
            $.ajax({
                url: 'http://jagroopsingh.byethost11.com/loginReg.php',
                data: {
                    'register': action,
                    'name': name,
                    'email': email,
                    'password': password
                },
                dataType: "jsonp",
                jsonp: "mycallback",
                success: function(response) {
                    $("#regbtn").html('<i class="fa fa-pencil-square-o"></i> Register');
                    if (response.register == "success") {
                       $("#reg_error").html("<span class='text-success'>You are successfully registered !</span>"); 
                    }
                    if (response.register == "already") {
                       $("#reg_error").html("<span class='text-danger'>You are already registered !</span>"); 
                    }
                    if (response.register == "error") {
                       $("#reg_error").html("<span class='text-danger'>Something Went Wrong Please Try Agian</span>"); 
                    }
                }
            });
        }


    }
}

function placesApi(action,query) {
        if (action == "lookupfor") {
            $("#finderresults").html("<center><i class='text-primary fa fa-spinner fa-pulse fa-4x'></i></center>");
            $.ajax({
                url: 'http://jagroopsingh.byethost11.com/places.php',
                data: {
                    'lookupfor': query                                        
                },
                 dataType: "jsonp",
                 jsonp: "mycallback",
                 success: function(response){
                 $("#finderresults").html("");
                 if (response.status == "ok") {                 
                 //$("#finderresults").append('<h3><span class="label label-info">'+response.total_results+'&nbsp; results found</span></h3><br>');
                 jQuery.each(response.places_data, function(i, val) {
                 $("#finderresults").append("<a href='javascript:void(0);' id='"+val.place_id+"' onclick='alert(this.id);' style='text-decoration: none;'><div class='panel mini-box'><span class='box-icon bg-info'></span><div class='box-info'><p class='size-h2'>"+val.name+"</p><div class='pull-right'><p class='text-muted'><i class='text-primary fa fa-road'></i> "+val.distance+"&nbsp;KM</p></div><p class='text-muted'><span data-i18n='New users'><i class='fa fa-map-marker'></i>&nbsp;"+val.addr+"</span></p></div></div></a>");                 
                 //console.log(val.name);
                 });
                 return false;
                 }
                },
                error : function(err){
                 alert("Error:"+err);
                }
            });
        }
        if (action == "place_details") {
                alert(query);
        }
}