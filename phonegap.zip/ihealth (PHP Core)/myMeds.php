<?php
include ('app/header.php');
require ('app/ihealth.php');
$ihealth = new ihealth;
$uid = (int)$_GET['uid'];
if(empty($_SESSION['user_id']) || empty($uid)){
    header("Location:meds.php");
}
$favos = $ihealth->getUserMeds($uid);
