<?php
$med = trim(ucfirst($_REQUEST['med']));
$url = "http://www.truemd.in/api/medicine_suggestions/?id=".urlencode($med)."&key=e14f70aa2c9c2220a23e65ae0eee29&limit=10";
$raw = file_get_contents($url);
$json = json_decode($raw,TRUE);
foreach($json['response']['suggestions'] as $foo){
	echo "<option value='".$foo['suggestion']."'>";
}