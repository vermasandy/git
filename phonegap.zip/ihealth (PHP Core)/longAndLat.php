<?php
session_start();
$_SESSION['location'] = htmlentities(htmlspecialchars(strip_tags($_REQUEST['location'])));
$location = $_SESSION['location'];
echo $location;