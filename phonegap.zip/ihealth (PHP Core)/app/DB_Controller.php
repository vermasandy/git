<?php
class DB_Controller {    
    public function __construct(){
     ob_start();
     session_start();
     $con = mysql_connect('localhost','root','root');
     mysql_select_db('ihealth',$con);
    }
}