<?php
require ('app/ihealth.php');
$instance = new ihealth;
if(isset($_POST['action'])){    
  $uid = (int)$_POST['uid'];
  $pname = (string)$_POST['pname'];
  $address = $_POST['address'];
  $phn = $_POST['phone'];
  $pid = (string)$_POST['pid'];
  $searchType = (string)$_POST['stype'];
  $favo = (string)$_POST['favo'];
  $action = (string)$_POST['action'];
  $add = $instance->addToFav($uid,$pname,$address,$phn,$pid,$searchType,$favo,$action);
  echo $add;
}
elseif(isset($_POST['delFav'])){
    $placeIdMatrix = (string)$_POST['placeId'];
    $del = $instance->delFav($placeIdMatrix);
    echo $del;
}
elseif(isset($_POST['favmed'])){
  $id = (int)$_POST['id'];
  $name = (string)$_POST['name'];
  $manuf = (string)$_POST['manu'];
  $cat = (string)$_POST['cat'];
  $price = (int)$_POST['price'];
  $action = $_POST['Medaction'];
  $addMed = $instance->addFavMed($id,$_SESSION['user_id'],$name,$manuf,$cat,$price,$action);
  echo $addMed;
}