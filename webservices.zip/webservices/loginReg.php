<?php
ob_start();
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type');
 $callback ='mycallback';
 
    if(isset($_GET['mycallback']))
    {
        $callback = $_GET['mycallback'];
    }
$con = mysql_connect('sql206.byethost11.com','b11_16182857','rooplakhnia007');
mysql_select_db('b11_16182857_phub',$con);	
    if(isset($_REQUEST['login'])){        
		$e = trim($_REQUEST['email']);
		$p = sha1($_REQUEST['password']);
		$q = "SELECT id,name FROM user WHERE email='$e' AND password='$p'";
        $query = mysql_query($q);
        $row = mysql_num_rows($query);
        if($row > 0){
            $result = mysql_fetch_assoc($query);
			$userdata['login'] = "success";
            $userdata['user_id'] = $result['id'];
            $userdata['user_name'] = $result['name'];            
            echo $callback.'(' . json_encode($userdata) . ')';
        }
        else{
			$msg['login'] = "error";
            $msg['msg'] = "Wrong Email Or password";
            echo $callback.'(' . json_encode($msg) . ')';
        }
    }
    elseif($_REQUEST['register']){		
        extract($_REQUEST);
		$password = sha1($password);
		$a = "SELECT email FROM user WHERE email = '$email'";
        $b = mysql_query($a);
        $rows = mysql_num_rows($b);
        if($rows > 0){
            $msg['register'] = "already";
            $msg['msg'] = "You Are already Registered";
            echo $callback.'(' . json_encode($msg) . ')';
			return false;
        }
        $q = "INSERT INTO user VALUES('','$name','$email','$password')";
        $sql = mysql_query($q);
        if($sql) {
            $msg['register'] = "success";
            $msg['msg'] = "You Are SuccessFully Registered";
            echo $callback.'(' . json_encode($msg) . ')';
        }
        else {
            $msg['register'] = "error";
            $msg['msg'] = "Something Went Wrong Please Try Agian";
            echo $callback.'(' . json_encode($msg) . ')';
			return false;
        }
    }
    else{
        $msg['auth'] = "error";
        $msg['msg'] = "You Are not authorized To do that";
        echo $callback.'(' . json_encode($msg) . ')';
		return false;
    }