<?php
ob_start();
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type');
 $callback ='mycallback';
 
    if(isset($_GET['mycallback']))
    {
        $callback = $_GET['mycallback'];
    }
if(isset($_GET['q']) && !empty($_GET['q'])){
      $medGet = urlencode(trim($_GET['q']));      
      $url = "http://www.truemd.in/api/medicine_details/?id={$medGet}&key=e14f70aa2c9c2220a23e65ae0eee29";
      $raw = file_get_contents($url);
      $med = json_decode($raw,TRUE);     
      if(!empty($med['response']['medicine'])){
        
        $med_details = array();
        $med_details['type'] = "details";
        $med_details['data'] = $med['response']['medicine'];
        $med_details['cons'] = $med['response']['constituents'];
      echo $callback.'(' . json_encode($med_details) . ')';       
      }
      else {
        $url = "http://www.truemd.in/api/medicine_suggestions/?id={$medGet}&key=e14f70aa2c9c2220a23e65ae0eee29";
        $raw = file_get_contents($url);
        $med = json_decode($raw,TRUE);        
        if(!empty($med['response']['suggestions'])){
            $suggestion = array();
            $suggestion['type'] = "suggestions";
            foreach($med['response']['suggestions'] as $sug):
            foreach($sug as $foo):
            $suggestion["data"]["suggestion".$i++] = $foo;
            endforeach;
            endforeach;            
         echo $callback.'(' . json_encode($suggestion) . ')';         
        } else {
            $response = array();
            $response['type'] = "empty";
            echo $callback.'(' . json_encode($response) . ')';
        }
      }
} 