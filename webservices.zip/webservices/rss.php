<?php
ob_start();
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type');
 $callback ='mycallback';
 
    if(isset($_GET['mycallback']))
    {
        $callback = $_GET['mycallback'];
    }
    if(isset($_GET['q']) && !empty($_GET['q'])){
        $file = "http://www.bodybuilding.com/rss/articles/{$_GET['q']}";
        $xml = simplexml_load_file($file);        
        echo $callback.'(' . json_encode($xml) . ')';
    }