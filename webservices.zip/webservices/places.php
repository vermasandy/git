<?php
ob_start();
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Max-Age: 1000');
header('Access-Control-Allow-Headers: Content-Type');
$callback = 'mycallback';
if (isset($_GET['mycallback'])) {
    $callback = $_GET['mycallback'];
}
//dictance calculation ==>>
function distance($lat1, $lon1, $lat2, $lon2, $unit) {

  $theta = $lon1 - $lon2;
  $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
  $dist = acos($dist);
  $dist = rad2deg($dist);
  $miles = $dist * 60 * 1.1515;
  $unit = strtoupper($unit);

  if ($unit == "K") {
    return ($miles * 1.609344);
  } else if ($unit == "N") {
      return ($miles * 0.8684);
    } else {
        return $miles;
      }
}
//<<== distance calculation ends
$location = "30.7500,76.7800";
$LocDistance = explode(',',$location);
if (isset($_REQUEST['lookupfor']) && !empty($_REQUEST['lookupfor']) || isset($_REQUEST['q']) && !empty($_REQUEST['q'])) {    
    $radius = 5000;
    if (isset($_REQUEST['exploreMore']) && !empty($_REQUEST['exploreMore'])) {
        $radius = 50000;
    }
    if (isset($_REQUEST['lookupfor'])) {
        $lookupfor = htmlentities(htmlspecialchars(strip_tags($_REQUEST['lookupfor'])));
        $type = array('hospital','pharmacy','dentist','food','doctor','spa','gym','veterinary_care','physiotherapist');
            if(!in_array($lookupfor,$type)){
                $msg           = array();
                $msg['status'] = "null";
                $msg['msg']    = "No results Found";
                echo $callback . '(' . json_encode($msg) . ')';
                return false;              
            }
        $url       = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location={$location}&radius={$radius}&types=" . $lookupfor . "&key=AIzaSyCq3nQrGPqdwxB8LY4dVepSsuZMdyIf1sw";
    }
    if (isset($_REQUEST['q'])) {
        $q   = htmlentities(htmlspecialchars(strip_tags($_REQUEST['q'])));
        $url = "https://maps.googleapis.com/maps/api/place/textsearch/json?location={$location}&radius=5000&types=food|cafe|hospital|gym|health|pharmacy|dentist|doctor|veterinary_care&query=" . urlencode($q) . "&key=AIzaSyCq3nQrGPqdwxB8LY4dVepSsuZMdyIf1sw";
    }
    $getJsonResponse = file_get_contents($url);
    $results         = json_decode($getJsonResponse, TRUE);
    if (empty($results['results'])) {
        $msg           = array();
        $msg['status'] = "null";
        $msg['msg']    = "No results Found";
        echo $callback . '(' . json_encode($msg) . ')';
        return false;
    } else {
        $lookUpResults                  = array();
        $i = 0;        
        foreach($results['results'] as $result):        
          $lookUpResults[$i]['name'] = $result['name'];
          $lookUpResults[$i]['place_id'] = $result['place_id'];
          $lookUpResults[$i]['addr'] = $result['vicinity'];
          $lookUpResults[$i]['distance'] = round(distance($LocDistance[0],$LocDistance[1],$result['geometry']['location']['lat'],$result['geometry']['location']['lng'],"K"),2);          
          $i++;
        endforeach;
        $data_return['status'] = "ok";
        $data_return['total_results'] = count($lookUpResults);
        $data_return['places_data'] = $lookUpResults;
        //echo "<pre>"; print_r($lookUpResults);
        //$lookUpResults                  = array();
        //$lookUpResults['status']        = "ok";
        //$lookUpResults['total_results'] = count($results['results']);
        //$lookUpResults['places_data']   = $results['results'];
        echo $callback . '(' . json_encode($data_return) . ')';
    }
}
